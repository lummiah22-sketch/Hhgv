async function adminLogin(){

    const email =
        document.getElementById("email").value;

    const password =
        document.getElementById("password").value;

    const msg =
        document.getElementById("msg");

    msg.innerText = "Checking...";

    try{

        const body = new URLSearchParams();

        body.append("username", email);
        body.append("password", password);


        const login =
            await fetch("/auth/login", {
                method:"POST",
                headers:{
                    "Content-Type":
                    "application/x-www-form-urlencoded"
                },
                body: body.toString()
            });


        const data =
            await login.json();


        if(!login.ok){
            throw new Error(
                data.detail || "Login failed"
            );
        }


        localStorage.setItem(
            "access_token",
            data.access_token
        );


        const me =
            await fetch("/users/me",{
                headers:{
                    "Authorization":
                    `Bearer ${data.access_token}`
                }
            });


        const user =
            await me.json();


        if(!user.is_admin){

            localStorage.removeItem(
                "access_token"
            );

            throw new Error(
                "Admin access required"
            );
        }


        window.location.href =
            "/admin.html";


    }catch(e){

        msg.innerText =
            e.message;
    }
}
