const gamesContainer = document.getElementById("gamesContainer");
const gameCount = document.getElementById("gameCount");
const searchInput = document.getElementById("searchInput");

let games = [];
let showingAllGames = false;
const HOME_GAME_LIMIT = 18;
const API = "http://127.0.0.1:8000";

/* ================= GAMES ================= */

async function loadGames() {
    try {
        const response = await fetch(`${API}/games`);

        console.log("status", response.status);

        if (!response.ok) {
            throw new Error("Failed to load games");
        }

        games = await response.json();

        console.log("games response", games);

        showingAllGames = false;
        renderGames(games.slice(0, HOME_GAME_LIMIT));

    } catch (error) {
        console.error("GAME LOAD ERROR:", error.message, error);

        gamesContainer.innerHTML = `
            <div class="loading">
                Failed to load games.
            </div>
        `;

        if (gameCount) gameCount.textContent = "0 games";
    }
}

function renderGames(gameList) {

    if (gameCount) gameCount.textContent = `${gameList.length} games`;

    if (gameList.length === 0) {
        gamesContainer.innerHTML = `
            <div class="loading">
                No games found.
            </div>
        `;
        return;
    }

    gamesContainer.innerHTML = gameList.map(game => `
        <article class="game-card">

            <div class="game-image">
                <img
                    src="${game.image_url || ''}"
                    alt="${game.name}"
                    loading="lazy"
                >
            </div>

            <div class="game-info">

                <h3>${game.name}</h3>

                <span class="badge">
                    Available
                </span>

                <button
                    class="game-button"
                    onclick="selectGame(${game.id})"
                >
                    Top Up
                </button>

            </div>

        </article>
    `).join("");
}


async function selectGame(gameId) {

    const game = games.find(
        game => game.id === gameId
    );

    if (!game) {
        return;
    }

    gamesContainer.innerHTML = `
        <div class="loading">
            Loading ${game.name}...
        </div>
    `;

    try {

        const response = await fetch(
            `${API}/games/${gameId}/currencies`
        );

        if (!response.ok) {
            throw new Error(
                "Failed to load currencies"
            );
        }

        const currencies = await response.json();

        showCurrencies(game, currencies);

    } catch (error) {

        console.error(error);

        gamesContainer.innerHTML = `
            <div class="loading">
                Failed to load currencies.
            </div>
        `;
    }
}

function showCurrencies(game, currencies) {

    if (currencies.length === 0) {
        gamesContainer.innerHTML = `
            <div class="loading">
                No packages available.
            </div>
        `;
        return;
    }

    const currency = currencies[0];

    gamesContainer.innerHTML = `
        <div class="package-view">

            <button
                class="back-games-btn"
                onclick="backToGamesFromPackages(event)"
            >
                ← Back to Games
            </button>

            <h2>${game.name}</h2>

            <div id="packagesContainer">
                <div class="loading">
                    Loading ${currency.name} packages...
                </div>
            </div>

        </div>
    `;

    loadPackages(
        currency.id,
        currency.name
    );
}


function backToGamesFromPackages(event) {
    if (event) {
        event.preventDefault();
    }

    renderGames(games);

    history.replaceState(
        {
            apexGamer: true,
            page: "games"
        },
        "",
        location.href
    );
}

async function loadPackages(currencyId, currencyName) {

    const packagesContainer =
        document.getElementById("packagesContainer");

    if (!packagesContainer) {
        return;
    }

    packagesContainer.innerHTML = `
        <div class="loading">
            Loading ${currencyName}...
        </div>
    `;

    try {

        const response = await fetch(
            `${API}/games/currencies/${currencyId}/packages`
        );

        if (!response.ok) {
            throw new Error(
                "Failed to load packages"
            );
        }

        const packages = await response.json();

        showPackages(
            packages,
            currencyName
        );

    } catch (error) {

        console.error(error);

        packagesContainer.innerHTML = `
            <div class="loading">
                Failed to load packages.
            </div>
        `;
    }
}

function showPackages(packages, currencyName) {

    const packagesContainer =
        document.getElementById("packagesContainer");

    if (!packagesContainer) {
        return;
    }

    if (packages.length === 0) {

        packagesContainer.innerHTML = `
            <div class="loading">
                No packages available.
            </div>
        `;

        return;
    }

    packagesContainer.innerHTML = `
        <h3 class="packages-title">
            ${currencyName} Packages
        </h3>

        <div class="packages-grid">

            ${packages.map(packageItem => `
                <div class="package-card">

                    <div class="package-info">

                        <div class="package-amount">
                            ${currencyName} ${packageItem.amount}
                        </div>

                        <div class="package-price">
                            ৳${packageItem.selling_price}
                        </div>

                    </div>

                    <button
                        class="buy-button"
                        onclick="buyPackage(
                            ${packageItem.id},
                            ${packageItem.amount},
                            ${packageItem.selling_price}
                        )"
                    >
                        Buy Now
                    </button>

                </div>
            `).join("")}

        </div>
    `;
}

/* ================= ORDER ================= */

async function buyPackage(packageId, amount, price) {

    const token = localStorage.getItem("access_token");

    /* ================= CHECKOUT UI ================= */

    const oldModal = document.getElementById("apexCheckoutModal");

    if (oldModal) {
        oldModal.remove();
    }

    const modal = document.createElement("div");

    modal.id = "apexCheckoutModal";

    modal.innerHTML = `
        <div style="
            position:fixed;
            inset:0;
            background:rgba(0,0,0,.75);
            z-index:99999;
            overflow-y:auto;
            padding:25px 15px;
        ">

            <div style="
                max-width:650px;
                margin:20px auto;
                background:#11172b;
                color:white;
                border-radius:20px;
                padding:24px;
                box-shadow:0 20px 60px rgba(0,0,0,.5);
            ">

                <div style="
                    display:flex;
                    justify-content:space-between;
                    align-items:center;
                    margin-bottom:20px;
                ">
                    <h2 style="margin:0;">
                        <span style="
                            background:#ff8a00;
                            border-radius:50%;
                            padding:8px 13px;
                            margin-right:8px;
                        ">2</span>
                        Account Info
                    </h2>

                    <button id="closeCheckout"
                        style="
                            background:#333b55;
                            color:white;
                            border:0;
                            padding:10px 15px;
                            border-radius:10px;
                            font-size:18px;
                        ">
                        ✕
                    </button>
                </div>

                <div style="
                    background:#1b2238;
                    border-radius:15px;
                    padding:20px;
                    margin-bottom:18px;
                ">

                    <h3 style="margin-top:0;">
                        Order Summary
                    </h3>

                    <div style="
                        background:#252c43;
                        padding:15px;
                        border-radius:10px;
                        margin-bottom:18px;
                    ">
                        <b>Package:</b> ${amount}<br>
                        <b>Price:</b> ৳${price}
                    </div>

                    <label style="
                        display:block;
                        font-weight:bold;
                        margin-bottom:8px;
                    ">
                        Player ID <span style="color:#ff5252;">*</span>
                    </label>

                    <input
                        id="apexPlayerId"
                        type="text"
                        placeholder="আপনার Player ID এখানে দিন"
                        style="
                            width:100%;
                            box-sizing:border-box;
                            padding:17px;
                            border-radius:14px;
                            border:2px solid #ff8a00;
                            background:#20273d;
                            color:white;
                            font-size:16px;
                            -webkit-text-size-adjust:100%;
                            text-size-adjust:100%;
                            outline:none;
                        "
                    >
                </div>

                <button
                    id="goPaymentBtn"
                    disabled
                    style="
                        width:100%;
                        padding:18px;
                        border:0;
                        border-radius:15px;
                        background:#ff8a00;
                        color:white;
                        font-size:19px;
                        font-weight:bold;
                        opacity:.5;
                    "
                >
                    Go to Payment — ৳${price}
                </button>

                <div id="paymentSection"
                    style="display:none;margin-top:20px;">

                    <h2>3. Payment</h2>

                    <div id="walletOption" style="
                        background:#20273d;
                        border:2px solid #39425d;
                        border-radius:14px;
                        padding:17px;
                        margin-bottom:10px;
                        cursor:pointer;
                    ">
                        💳 Wallet Pay
                    </div>

                    <div id="manualOption" style="
                        background:#20273d;
                        border:2px solid #39425d;
                        border-radius:14px;
                        padding:17px;
                        cursor:pointer;
                    ">
                        📱 Manual Payment
                    </div>

                    <div id="manualPaymentBox"
                        style="display:none;margin-top:15px;">

                        <input
                            id="paymentMethod"
                            type="text"
                            placeholder="Payment Method (bKash/Nagad/Rocket/USDT)"
                            style="
                                width:100%;
                                box-sizing:border-box;
                                padding:15px;
                                margin-bottom:10px;
                                border-radius:10px;
                                border:1px solid #555;
                                background:#20273d;
                                color:white;
                            "
                        >

    			<input
                            id="customerEmail"
      			    type="email"
			    placeholder="Your Gmail Address"
			    required
			    style="
		                width:100%;
			        box-sizing:border-box;
			        padding:15px;
			        margin-bottom:10px;
			        border-radius:10px;
			        border:1px solid #555;
			        background:#20273d;
			        color:white;
			        font-size:16px;
                            -webkit-text-size-adjust:100%;
                            text-size-adjust:100%;
                            "
     			>

                        <input
                            id="transactionId"
                            type="text"
                            placeholder="Transaction ID"
                            style="
                                width:100%;
                                box-sizing:border-box;
                                padding:15px;
                                border-radius:10px;
                                border:1px solid #555;
                                background:#20273d;
                                color:white;
                            "
                        >

                    </div>

                    <button
                        id="confirmPaymentBtn"
                        style="
                            width:100%;
                            padding:18px;
                            margin-top:18px;
                            border:0;
                            border-radius:15px;
                            background:#0d6efd;
                            color:white;
                            font-size:18px;
                            font-weight:bold;
                        "
                    >
                        Confirm Payment
                    </button>

                </div>

            </div>
        </div>
    `;

    document.body.appendChild(modal);

    /* ================= ELEMENTS ================= */

    const playerInput =
        document.getElementById("apexPlayerId");

    const goPaymentBtn =
        document.getElementById("goPaymentBtn");

    const paymentSection =
        document.getElementById("paymentSection");

    const walletOption =
        document.getElementById("walletOption");

    const manualOption =
        document.getElementById("manualOption");

    const manualPaymentBox =
        document.getElementById("manualPaymentBox");

    const confirmPaymentBtn =
        document.getElementById("confirmPaymentBtn");

    let selectedPayment = null;

    /* ================= CLOSE ================= */

    document.getElementById("closeCheckout")
        .onclick = () => modal.remove();

    /* ================= PLAYER ID ================= */

    playerInput.addEventListener("input", () => {

        const valid =
            playerInput.value.trim().length > 0;

        goPaymentBtn.disabled = !valid;

        goPaymentBtn.style.opacity =
            valid ? "1" : ".5";
    });

    /* ================= GO PAYMENT ================= */

    goPaymentBtn.onclick = () => {

        const playerId =
            playerInput.value.trim();

        if (!playerId) {
            alert("Player ID দিন।");
            return;
        }

        paymentSection.style.display = "block";

        paymentSection.scrollIntoView({
            behavior: "smooth"
        });
    };

    /* ================= WALLET ================= */

    walletOption.onclick = async () => {

        if (!token) {
            closeLoginRequired();
            openLogin();
            return;
        }

    selectedPayment = "wallet";

    walletOption.style.border =
        "2px solid #ff8a00";

    manualOption.style.border =
        "2px solid #39425d";

    manualPaymentBox.style.display =
        "none";

    walletOption.innerHTML = `
        <div style="
            font-size:18px;
            font-weight:bold;
        ">
            💳 Wallet Payment
        </div>

        <div id="walletInfo" style="
            margin-top:12px;
            padding:14px;
            background:#171d31;
            border-radius:10px;
            line-height:1.8;
        ">
            Loading wallet balance...
        </div>
    `;

    try {

        const response = await fetch(`${API}/wallet`, {
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(
                data.detail ||
                "Wallet balance পাওয়া যায়নি"
            );
        }

        const balance =
            Number(data.wallet_balance || 0);

        const remaining =
            balance - Number(price);

        document.getElementById("walletInfo").innerHTML = `
            <div>
                Wallet Balance:
                <b>৳${balance}</b>
            </div>

            <div>
                Order Amount:
                <b>৳${price}</b>
            </div>

            <div>
                Remaining Balance:
                <b style="
                    color:${remaining >= 0
                        ? '#35d07f'
                        : '#ff5252'};
                ">
                    ৳${remaining}
                </b>
            </div>

            ${
                remaining >= 0
                ? `
                    <div style="
                        margin-top:10px;
                        color:#35d07f;
                        font-weight:bold;
                    ">
                        ✅ আপনি ApexGamer Wallet দিয়ে
                        payment করছেন
                    </div>
                `
                : `
                    <div style="
                        margin-top:10px;
                        color:#ff5252;
                        font-weight:bold;
                    ">
                        ❌ Wallet balance যথেষ্ট নয়
                    </div>
                `
            }
        `;

        if (remaining >= 0) {

            confirmPaymentBtn.disabled = false;

            confirmPaymentBtn.innerText =
                `Pay ৳${price} from Wallet`;

        } else {

            confirmPaymentBtn.disabled = true;

            confirmPaymentBtn.innerText =
                "Insufficient Wallet Balance";
        }

    } catch (error) {

        document.getElementById("walletInfo").innerHTML = `
            <div style="color:#ff5252;">
                ❌ ${error.message}
            </div>
        `;

        confirmPaymentBtn.disabled = true;
    }
};


/* ================= MANUAL PAYMENT ================= */

manualOption.onclick = () => {

    selectedPayment = "manual";

    loadPaymentAccounts();

    manualOption.style.border =
        "2px solid #ff8a00";

    walletOption.style.border =
        "2px solid #39425d";

    manualPaymentBox.style.display =
        "block";

    confirmPaymentBtn.disabled = false;

    confirmPaymentBtn.innerText =
        "Confirm Payment";
};

    /* ================= CONFIRM ================= */

    confirmPaymentBtn.onclick = async () => {

        const playerId =
            playerInput.value.trim();

        if (!playerId) {
            alert("Player ID দিন।");
            return;
        }

        if (!selectedPayment) {
            alert("একটি Payment Method নির্বাচন করুন।");
            return;
        }

        confirmPaymentBtn.disabled = true;
        confirmPaymentBtn.innerText =
            "Processing...";

        try {

            /* ================= CREATE ORDER ================= */

            const orderUrl =
                `${API}/orders?package_id=${encodeURIComponent(packageId)}` +
                `&player_id=${encodeURIComponent(playerId)}`;

            const orderResponse =
                await fetch(orderUrl, {
                    method: "POST",
                    headers: token
                        ? {
                            "Authorization":
                                `Bearer ${token}`
                        }
                        : {}
                });

            const orderData =
                await orderResponse.json();

            if (!orderResponse.ok) {
                throw new Error(
                    orderData.detail ||
                    "Order তৈরি করা যায়নি"
                );
            }

            const orderId =
                orderData.order_id;

            /* ================= WALLET ================= */

            if (selectedPayment === "wallet") {

                const walletResponse =
                    await fetch(
                        `${API}/orders/${orderId}/wallet-payment`,
                        {
                            method: "POST",
                            headers: {
                                "Authorization":
                                    `Bearer ${token}`
                            }
                        }
                    );

                const walletData =
                    await walletResponse.json();

                if (!walletResponse.ok) {
                    throw new Error(
                        walletData.detail ||
                        "Wallet payment failed"
                    );
                }

                alert(
                    `✅ Payment Successful!\n\n` +
                    `Order ID: #${walletData.order_id}\n` +
                    `Player ID: ${playerId}\n` +
                    `Amount: ৳${walletData.price}\n` +
                    `Status: ${walletData.status || "processing"}`
                );

                modal.remove();

                return;
            }

            /* ================= MANUAL PAYMENT ================= */

            const paymentMethod =
                document
                    .getElementById("paymentMethod")
                    .value
                    .trim();

            const transactionId =
                document
                    .getElementById("transactionId")
                    .value
                    .trim();
            
            const customerEmail =
                document
                    .getElementById("customerEmail")
                    .value
                    .trim();

            if (!customerEmail) {
                throw new Error("Email Address দিন।");
            }

            if (!paymentMethod) {
                throw new Error(
                    "Payment Method দিন।"
                );
            }

            if (!transactionId) {
                throw new Error(
                    "Transaction ID দিন।"
                );
            }

            const paymentUrl =
     	        `/orders/${orderId}/payment` +
	        `?payment_method=${encodeURIComponent(paymentMethod)}` +
	        `&transaction_id=${encodeURIComponent(transactionId)}` +
	        `&customer_email=${encodeURIComponent(customerEmail)}`;

            const paymentResponse =
                await fetch(
                    `${API}${paymentUrl}`,
                    {
                        method: "POST"
           	    }
	        );

            const paymentData =
                await paymentResponse.json();

            if (!paymentResponse.ok) {
                throw new Error(
                    paymentData.detail ||
                    "Payment failed"
                );
            }

            showPaymentSuccess(
                paymentData.order_id || orderId,
	        playerId,
                paymentData.order_status || "processing"
            );

            modal.remove();
            return;
        } catch (error) {

            console.error(error);

            showPaymentError(
                error.message ||
                "Something went wrong."
            );

            confirmPaymentBtn.disabled = false;
            confirmPaymentBtn.innerText =
                "Confirm Payment";
        }
    };
}

/* ================= SEARCH ================= */

(function () {

    const searchBox = searchInput?.parentElement;

    if (!searchInput || !searchBox) {
        return;
    }

    searchBox.style.position = "relative";

    let suggestionBox =
        document.getElementById("gameSearchSuggestions");

    if (!suggestionBox) {
        suggestionBox = document.createElement("div");
        suggestionBox.id = "gameSearchSuggestions";

        searchBox.appendChild(suggestionBox);
    }

    function showSuggestions(list) {

        if (!list.length) {
            suggestionBox.innerHTML = `
                <div class="search-no-result">
                    No game found
                </div>
            `;

            suggestionBox.style.display = "block";
            return;
        }

        suggestionBox.innerHTML = list
            .slice(0, 6)
            .map(game => `
                <div
                    class="search-suggestion"
                    onclick="selectSearchGame(${game.id})"
                >
                    <img
                        src="${game.image_url || ''}"
                        alt=""
                    >

                    <span>${game.name}</span>
                </div>
            `)
            .join("");

        suggestionBox.style.display = "block";
    }


    window.selectSearchGame = function (gameId) {

        const game = games.find(
            game => game.id === Number(gameId)
        );

        if (!game) {
            return;
        }

        searchInput.value = game.name;

        suggestionBox.style.display = "none";

        // শুধু selected game দেখাবে
        renderGames([game]);

        // Games section-এ নিয়ে যাবে
        setTimeout(() => {

            const section =
                document.getElementById("gamesContainer");

            if (section) {
                section.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });
            }

        }, 100);

    };


    searchInput.addEventListener("input", function () {

        const searchText =
            this.value.toLowerCase().trim();

        if (!searchText) {

            suggestionBox.style.display = "none";

            renderGames(games);

            return;
        }

        const filteredGames =
            games.filter(game =>
                game.name
                    .toLowerCase()
                    .includes(searchText)
            );

        showSuggestions(filteredGames);

        // exact/single match হলে সরাসরি শুধু সেই game দেখাবে
        if (filteredGames.length === 1) {

            renderGames(filteredGames);

            setTimeout(() => {

                const section =
                    document.getElementById("gamesContainer");

                if (section) {
                    section.scrollIntoView({
                        behavior: "smooth",
                        block: "start"
                    });
                }

            }, 150);
        }

    });


    // বাইরে click করলে suggestion বন্ধ
    document.addEventListener("click", function (event) {

        if (!searchBox.contains(event.target)) {
            suggestionBox.style.display = "none";
        }

    });

})();


/* ================= POPULAR PRODUCTS ================= */

async function loadPopularProducts() {

    try {

        const response = await fetch(
             `${API}/games/popular-products` 		
        );

        if (!response.ok) {
            throw new Error(
                "Failed to load popular products"
            );
        }

        const products =
            await response.json();

        renderPopularProducts(products);

    } catch (error) {

        console.error(error);
    }
}


function renderPopularProducts(products) {

    const productsGrid =
        document.querySelector(".products-grid");

    if (!productsGrid) {
        return;
    }

    productsGrid.innerHTML =
        products.map(product => `
            <div class="product-card">

                <div class="product-image">
                    ${product.currency_name}
                </div>

                <h3>
                    ${product.amount}
                    ${product.currency_name}
                </h3>

                <p>
                    ${product.game_name}
                </p>

                <strong>
                    ৳${product.selling_price}
                </strong>

                <button
                    onclick="buyPackage(
                        ${product.id},
                        ${product.amount},
                        ${product.selling_price}
                    )"
                >
                    Buy Now
                </button>

            </div>
        `).join("");
}


/* ================= AUTH ================= */

const loginModal =
    document.getElementById("loginModal");

const loginForm =
    document.getElementById("loginForm");

const signupForm =
    document.getElementById("signupForm");

const loginMessage =
    document.getElementById("loginMessage");

const authTitle =
    document.getElementById("authTitle");

const authSubtitle =
    document.getElementById("authSubtitle");

const switchText =
    document.getElementById("switchText");

const switchAuth =
    document.getElementById("switchAuth");


let authMode = "login";


function openLogin() {

    if (!loginModal) {
        return;
    }

    authMode = "login";

    updateAuthForm();

    loginModal.style.display = "flex";
}


function closeLogin() {

    if (!loginModal) {
        return;
    }

    loginModal.style.display = "none";

    if (loginMessage) {
        loginMessage.textContent = "";
    }
}


function updateAuthForm() {

    if (loginMessage) {
        loginMessage.textContent = "";
    }

    if (authMode === "login") {

        authTitle.textContent =
            "Welcome to ApexGamer";

        authSubtitle.textContent =
            "Login to continue";

        loginForm.style.display =
            "flex";

        signupForm.style.display =
            "none";

        switchText.textContent =
            "Don't have an account?";

        switchAuth.textContent =
            "Sign Up";

    } else {

        authTitle.textContent =
            "Create ApexGamer Account";

        authSubtitle.textContent =
            "Create your account to continue";

        loginForm.style.display =
            "none";

        signupForm.style.display =
            "flex";

        switchText.textContent =
            "Already have an account?";

        switchAuth.textContent =
            "Login";
    }
}


if (switchAuth) {

    switchAuth.addEventListener(
        "click",
        function () {

            if (authMode === "login") {
                authMode = "signup";
            } else {
                authMode = "login";
            }

            updateAuthForm();
        }
    );

}


/* Header Login buttons */

document
    .querySelectorAll(".login-btn, .nav-login")
    .forEach(button => {

        button.addEventListener(
            "click",
            openLogin
        );

    });


/* ================= LOGIN ================= */

if (loginForm) {

    loginForm.addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();

            const email =
                document.getElementById(
                    "loginEmail"
                ).value.trim();

            const password =
                document.getElementById(
                    "loginPassword"
                ).value;


            loginMessage.textContent =
                "Logging in...";


            try {

                /*
                 * Current backend accepts:
                 * /auth/login?email=...&password=...
                 */

                const loginBody = new URLSearchParams();

                loginBody.append("username", email);
                loginBody.append("password", password);

		const response = await fetch(
		    `${API}/auth/login`,
                    {

                        method: "POST",
                        headers: {
                            "Content-Type": "application/x-www-form-urlencoded"
                        },
                        body: loginBody.toString()
                     } 
                );
                
                const data =
                    await response.json();


                if (!response.ok) {

                    throw new Error(
                        data.detail ||
                        "Login failed"
                    );
                }


                localStorage.setItem(
                    "access_token",
                    data.access_token
                );


                loginMessage.textContent =
                    "Login successful!";


                setTimeout(
                    closeLogin,
                    800
                );


            } catch (error) {

                console.error(error);

                loginMessage.textContent =
                    error.message;
            }

        }
    );

}


/* ================= SIGNUP ================= */

if (signupForm) {

    signupForm.addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();

            const name =
                document.getElementById(
                    "signupName"
                ).value.trim();

            const email =
                document.getElementById(
                    "signupEmail"
                ).value.trim();

            const password =
                document.getElementById(
                    "signupPassword"
                ).value;


            loginMessage.textContent =
                "Creating account...";


            try {

                const response =
                    await fetch(
                        "/users",
                        {
                            method: "POST",

                            headers: {
                                "Content-Type":
                                    "application/json"
                            },

                            body: JSON.stringify({
                                name: name,
                                email: email,
                                password: password
                            })
                        }
                    );


                const rawResponse =
                    await response.text();

                let data = {};

                try {
                    data = rawResponse
                        ? JSON.parse(rawResponse)
                        : {};
                } catch (e) {
                    throw new Error(
                        rawResponse ||
                        "Server returned an invalid response"
                    );
                }


                if (!response.ok) {

                    throw new Error(
                        data.detail ||
                        data.message ||
                        "Signup failed"
                    );
                }


                loginMessage.textContent =
                    "Account created! Please login.";


                setTimeout(
                    function () {

                        authMode = "login";

                        updateAuthForm();

                        document.getElementById(
                            "loginEmail"
                        ).value = email;

                    },
                    1000
                );


            } catch (error) {

                console.error(error);

                loginMessage.textContent =
                    error.message;
            }

        }
    );

}


/* ================= START ================= */

console.log("START TEST"); loadGames();
loadPopularProducts();

function openAdminPanel() {
    const token = localStorage.getItem("access_token");

    if (!token) {
        alert("Please login first.");
        return;
    }

    window.location.href = "/admin.html";
}

function goHome(event) {
    if (event) event.preventDefault();
    window.scrollTo({ top: 0, behavior: "smooth" });
}

function goGames(event) {
    if (event) event.preventDefault();
    const el = document.querySelector(".games-section")
        || document.querySelector("#games")
        || document.querySelector(".games-grid");

    if (el) {
        el.scrollIntoView({ behavior: "smooth" });
    }
}

function maskWalletNumber(number) {
    return String(number || "");
}

async function openWallet(event) {
    if (event) event.preventDefault();

    const token = localStorage.getItem("access_token");

    if (!token) {
        closeLoginRequired();
        openLogin();
        return;
    }

    try {
        /* ================= WALLET BALANCE ================= */

        const response = await fetch(`${API}/wallet`, {
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });

        const data = await response.json();

        if (!response.ok) {
            if (response.status === 401) {
                localStorage.removeItem("access_token");
                showLoginExpiredPopup();
                return;
            }

            throw new Error(
                data.detail || "Wallet load করা যায়নি"
            );
        }

        const balance = Number(data.wallet_balance || 0);

        /* ================= PAYMENT ACCOUNTS ================= */

        let accounts = [];

        try {
            const accountResponse =
                await fetch(`${API}/payment-accounts`);

            if (accountResponse.ok) {
                accounts = await accountResponse.json();
            }
        } catch (e) {
            console.log("Payment accounts load failed", e);
        }

        const methodNames = ["bKash", "Nagad", "Rocket", "USDT"];

        const availableAccounts = methodNames.map(method => {
            return accounts.find(
                a =>
                    String(a.method || "").toLowerCase() ===
                    method.toLowerCase()
            );
        }).filter(Boolean);

        let selectedAccount =
            availableAccounts[0] || null;

        const accountHTML = availableAccounts.length
            ? availableAccounts.map((account, index) => `
                <button
                    type="button"
                    class="wallet-payment-card ${index === 0 ? "active" : ""}"
                    data-method="${account.method}"
                    data-account="${account.account_number}"
                    data-type="${account.account_type || ""}"
                    data-network="${account.network || ""}"
                    style="
                        width:100%;
                        display:flex;
                        align-items:center;
                        gap:12px;
                        padding:12px;
                        margin-bottom:10px;
                        border-radius:14px;
                        border:2px solid ${index === 0 ? "#1683ff" : "#263653"};
                        background:${index === 0 ? "#102d50" : "#121d32"};
                        color:white;
                        text-align:left;
                        cursor:pointer;
                        box-sizing:border-box;
                    "
                >
                    <div style="
                        width:44px;
                        height:44px;
                        min-width:44px;
                        border-radius:12px;
                        background:#fff;
                        display:flex;
                        align-items:center;
                        justify-content:center;
                        overflow:hidden;
                    ">
                        ${
                            account.image_url
                            ? `<img
                                src="${account.image_url}"
                                alt="${account.method}"
                                style="
                                    width:38px;
                                    height:38px;
                                    object-fit:contain;
                                "
                            >`
                            : "💳"
                        }
                    </div>

                    <div style="
                        flex:1;
                        min-width:0;
                    ">
                        <div style="
                            font-size:16px;
                            -webkit-text-size-adjust:100%;
                            text-size-adjust:100%;
                            font-weight:800;
                            margin-bottom:3px;
                        ">
                            ${account.method}
                        </div>

                        <div style="
                            color:#91a4c2;
                            font-size:13px;
                        ">
                            ${account.account_type || ""}
                            ${account.network ? " • " + account.network : ""}
                        </div>
                    </div>

                    <div style="
                        font-size:20px;
                        color:${index === 0 ? "#1683ff" : "#667895"};
                    ">
                        ${index === 0 ? "✓" : "○"}
                    </div>
                </button>
            `).join("")
            : `
                <div style="
                    padding:14px;
                    border-radius:12px;
                    background:#171f33;
                    color:#9aa9c0;
                    text-align:center;
                ">
                    Payment accounts unavailable
                </div>
            `;

        const html = `
            <div id="walletModal" style="
                position:fixed;
                inset:0;
                z-index:99999;
                background:rgba(3,8,20,.82);
                backdrop-filter:blur(6px);
                -webkit-backdrop-filter:blur(6px);
                overflow-y:auto;
                padding:14px;
                box-sizing:border-box;
            ">

                <div style="
                    width:100%;
                    max-width:520px;
                    margin:18px auto;
                    background:#0c1428;
                    color:#fff;
                    border:1px solid #263653;
                    border-radius:24px;
                    overflow:hidden;
                    box-shadow:0 25px 80px rgba(0,0,0,.55);
                ">

                    <!-- HEADER -->
                    <div style="
                        padding:20px;
                        display:flex;
                        align-items:center;
                        justify-content:space-between;
                        border-bottom:1px solid #202d46;
                        background:linear-gradient(135deg,#101d37,#0b1427);
                    ">

                        <div style="
                            display:flex;
                            align-items:center;
                            gap:12px;
                        ">
                            <div style="
                                width:48px;
                                height:48px;
                                border-radius:14px;
                                background:linear-gradient(135deg,#1683ff,#35b6ff);
                                display:flex;
                                align-items:center;
                                justify-content:center;
                                font-size:25px;
                            ">
                                💳
                            </div>

                            <div>
                                <div style="
                                    font-size:23px;
                                    font-weight:900;
                                    line-height:1.1;
                                ">
                                    My Wallet
                                </div>

                                <div style="
                                    color:#8ea0bc;
                                    font-size:13px;
                                    margin-top:4px;
                                ">
                                    Manage your ApexGamer balance
                                </div>
                            </div>
                        </div>

                        <button
                            type="button"
                            onclick="document.getElementById('walletModal').remove()"
                            style="
                                width:42px;
                                height:42px;
                                border:0;
                                border-radius:12px;
                                background:#202b42;
                                color:#fff;
                                font-size:22px;
                                cursor:pointer;
                            "
                        >
                            ✕
                        </button>
                    </div>


                    <!-- BALANCE -->
                    <div style="
                        margin:18px;
                        padding:22px;
                        border-radius:20px;
                        background:
                            linear-gradient(
                                135deg,
                                #0c3d78,
                                #0754a5,
                                #0875d9
                            );
                        position:relative;
                        overflow:hidden;
                    ">

                        <div style="
                            position:absolute;
                            width:150px;
                            height:150px;
                            right:-50px;
                            top:-60px;
                            border-radius:50%;
                            background:rgba(255,255,255,.08);
                        "></div>

                        <div style="
                            color:#b9d9ff;
                            font-size:14px;
                            font-weight:700;
                        ">
                            AVAILABLE BALANCE
                        </div>

                        <div style="
                            font-size:36px;
                            font-weight:900;
                            margin-top:8px;
                            letter-spacing:.3px;
                        ">
                            ৳${balance.toLocaleString("en-BD")}
                        </div>

                        <div style="
                            margin-top:12px;
                            color:#d9ecff;
                            font-size:13px;
                        ">
                            Use your wallet for faster game top-ups
                        </div>
                    </div>


                    <!-- ADD MONEY -->
                    <div style="
                        padding:0 18px 20px;
                    ">

                        <div style="
                            display:flex;
                            align-items:center;
                            gap:9px;
                            margin-bottom:12px;
                        ">
                            <span style="
                                width:30px;
                                height:30px;
                                border-radius:9px;
                                background:#123d68;
                                display:flex;
                                align-items:center;
                                justify-content:center;
                            ">
                                +
                            </span>

                            <div style="
                                font-size:19px;
                                font-weight:800;
                            ">
                                Add Money
                            </div>
                        </div>

                        <div style="
                            color:#8495b1;
                            font-size:13px;
                            margin-bottom:14px;
                        ">
                            Select a payment method and send money to the account below.
                        </div>


                        <!-- PAYMENT METHODS -->
                        <div id="walletPaymentAccounts">
                            ${accountHTML}
                        </div>


                        <!-- SELECTED ACCOUNT -->
                        <div id="walletSelectedAccount" style="
                            margin-top:12px;
                            padding:15px;
                            border-radius:16px;
                            background:#101d32;
                            border:1px solid #263653;
                        ">

                            ${
                                selectedAccount
                                ? `
                                    <div style="
                                        color:#8ea0bc;
                                        font-size:12px;
                                        margin-bottom:6px;
                                    ">
                                        SEND MONEY TO
                                    </div>

                                    <div style="
                                        display:flex;
                                        align-items:center;
                                        gap:8px;
                                    ">

                                        <div id="walletAccountNumber" style="
                                            flex:1;
                                            font-size:21px;
                                            font-weight:900;
                                            letter-spacing:.5px;
                                            word-break:break-all;
                                        ">
                                            ${selectedAccount.account_number}
                                        </div>

                                        <button
                                            type="button"
                                            id="walletCopyBtn"
                                            style="
                                                border:0;
                                                background:#1683ff;
                                                color:#fff;
                                                padding:9px 12px;
                                                border-radius:9px;
                                                font-weight:700;
                                                cursor:pointer;
                                            "
                                        >
                                            📋 Copy
                                        </button>
                                    </div>

                                    <div style="
                                        margin-top:7px;
                                        color:#7f91ae;
                                        font-size:12px;
                                    ">
                                        ${selectedAccount.account_type || ""}
                                        ${selectedAccount.network ? " • " + selectedAccount.network : ""}
                                    </div>
                                `
                                : `
                                    <div style="color:#8ea0bc;">
                                        Payment account not available.
                                    </div>
                                `
                            }

                        </div>


                        <!-- AMOUNT -->
                        <label style="
                            display:block;
                            margin-top:16px;
                            margin-bottom:7px;
                            font-size:13px;
                            font-weight:700;
                            color:#b7c4d8;
                        ">
                            Amount
                        </label>

                        <div style="position:relative;">
                            <span style="
                                position:absolute;
                                left:14px;
                                top:50%;
                                transform:translateY(-50%);
                                color:#7e91ad;
                                font-weight:700;
                            ">
                                ৳
                            </span>

                            <input
                                id="walletAmount"
                                type="number"
                                min="1"
                                inputmode="decimal"
                                placeholder="Enter amount"
                                style="
                                    width:100%;
                                    height:52px;
                                    padding:0 14px 0 34px;
                                    border-radius:13px;
                                    border:1px solid #2a3a57;
                                    background:#111d32;
                                    color:#fff;
                                    outline:none;
                                    font-size:16px;
                            -webkit-text-size-adjust:100%;
                            text-size-adjust:100%;
                                    box-sizing:border-box;
                                "
                            >
                        </div>


                        <!-- TRANSACTION ID -->
                        <label style="
                            display:block;
                            margin-top:14px;
                            margin-bottom:7px;
                            font-size:13px;
                            font-weight:700;
                            color:#b7c4d8;
                        ">
                            Transaction ID / TXID
                        </label>

                        <input
                            id="walletTransactionId"
                            type="text"
                            autocomplete="off"
                            placeholder="Enter transaction ID"
                            style="
                                width:100%;
                                height:52px;
                                padding:0 14px;
                                border-radius:13px;
                                border:1px solid #2a3a57;
                                background:#111d32;
                                color:#fff;
                                outline:none;
                                font-size:16px;
                            -webkit-text-size-adjust:100%;
                            text-size-adjust:100%;
                                box-sizing:border-box;
                            "
                        >


                        <!-- SUBMIT -->
                        <button
                            type="button"
                            onclick="submitWalletDeposit()"
                            style="
                                width:100%;
                                height:54px;
                                margin-top:16px;
                                border:0;
                                border-radius:14px;
                                background:linear-gradient(135deg,#087cff,#1267db);
                                color:#fff;
                                font-size:16px;
                            -webkit-text-size-adjust:100%;
                            text-size-adjust:100%;
                                font-weight:900;
                                cursor:pointer;
                                box-shadow:0 8px 25px rgba(8,124,255,.25);
                            "
                        >
                            Submit Deposit
                        </button>


                        <div style="
                            margin-top:13px;
                            padding:11px;
                            border-radius:11px;
                            background:#101a2d;
                            color:#71839f;
                            text-align:center;
                            font-size:12px;
                            line-height:1.5;
                        ">
                            🛡️ Deposit requests are reviewed and approved by ApexGamer Admin.
                        </div>

                    </div>

                </div>
            </div>
        `;

        document.body.insertAdjacentHTML("beforeend", html);


        /* ================= PAYMENT METHOD CLICK ================= */

        const cards =
            document.querySelectorAll(
                "#walletPaymentAccounts .wallet-payment-card"
            );

        const selectedBox =
            document.getElementById(
                "walletSelectedAccount"
            );

        cards.forEach(card => {

            card.addEventListener("click", () => {

                cards.forEach(c => {
                    c.classList.remove("active");
                    c.style.border = "2px solid #263653";
                    c.style.background = "#121d32";

                    const icon = c.querySelector("div:last-child");

                    if (icon) {
                        icon.style.color = "#667895";
                        icon.textContent = "○";
                    }
                });

                card.classList.add("active");

                card.style.border =
                    "2px solid #1683ff";

                card.style.background =
                    "#102d50";

                const icon =
                    card.querySelector("div:last-child");

                if (icon) {
                    icon.style.color = "#1683ff";
                    icon.textContent = "✓";
                }

                const method =
                    card.dataset.method || "";

                const account =
                    card.dataset.account || "";

                const type =
                    card.dataset.type || "";

                const network =
                    card.dataset.network || "";

                selectedAccount = {
                    method,
                    account_number: account,
                    account_type: type,
                    network
                };

                selectedBox.innerHTML = `
                    <div style="
                        color:#8ea0bc;
                        font-size:12px;
                        margin-bottom:6px;
                    ">
                        SEND MONEY TO
                    </div>

                    <div style="
                        display:flex;
                        align-items:center;
                        gap:8px;
                    ">
                        <div
                            id="walletAccountNumber"
                            style="
                                flex:1;
                                font-size:21px;
                                font-weight:900;
                                word-break:break-all;
                            "
                        >
                            ${account}
                        </div>

                        <button
                            type="button"
                            id="walletCopyBtn"
                            style="
                                border:0;
                                background:#1683ff;
                                color:#fff;
                                padding:9px 12px;
                                border-radius:9px;
                                font-weight:700;
                                cursor:pointer;
                            "
                        >
                            📋 Copy
                        </button>
                    </div>

                    <div style="
                        margin-top:7px;
                        color:#7f91ae;
                        font-size:12px;
                    ">
                        ${type}
                        ${network ? " • " + network : ""}
                    </div>
                `;

                setupWalletCopy();
            });
        });


        /* ================= COPY ================= */

        function setupWalletCopy() {

            const copyBtn =
                document.getElementById(
                    "walletCopyBtn"
                );

            if (!copyBtn) return;

            copyBtn.onclick = async () => {

                const number =
                    document.getElementById(
                        "walletAccountNumber"
                    )?.textContent.trim();

                if (!number) return;

                try {
                    await navigator.clipboard.writeText(number);

                    copyBtn.textContent = "✓ Copied";

                    setTimeout(() => {
                        copyBtn.textContent = "📋 Copy";
                    }, 1500);

                } catch (e) {
                    alert("Copy করা যায়নি।");
                }
            };
        }

        setupWalletCopy();

    } catch (error) {

        console.error(error);

        alert(
            "❌ " +
            (error.message || "Wallet load করা যায়নি")
        );
    }
}



function showLoginExpiredPopup() {
    const old = document.getElementById("loginExpiredPopup");
    if (old) old.remove();

    const modal = document.createElement("div");
    modal.id = "loginExpiredPopup";

    modal.innerHTML = `
        <div style="
            position:fixed;
            inset:0;
            background:rgba(0,0,0,.65);
            backdrop-filter:blur(4px);
            z-index:1000000;
            display:flex;
            align-items:center;
            justify-content:center;
            padding:20px;
        ">
            <div style="
                width:100%;
                max-width:380px;
                background:#111c35;
                color:white;
                border:1px solid #263d63;
                border-radius:20px;
                padding:26px 22px;
                text-align:center;
                box-shadow:0 20px 60px rgba(0,0,0,.5);
            ">
                <div style="
                    width:62px;
                    height:62px;
                    margin:0 auto 15px;
                    border-radius:50%;
                    background:#17345f;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    font-size:30px;
                ">
                    🔐
                </div>

                <h2 style="
                    margin:0 0 10px;
                    font-size:22px;
                ">
                    Login Required
                </h2>

                <p style="
                    margin:0 0 22px;
                    color:#aebbd1;
                    line-height:1.5;
                    font-size:15px;
                ">
                    Your login session has expired.
                    Please login again to continue.
                </p>

                <div style="
                    display:flex;
                    gap:10px;
                ">
                    <button id="expiredCancelBtn" style="
                        flex:1;
                        min-height:48px;
                        border:1px solid #34496b;
                        border-radius:11px;
                        background:#1a2740;
                        color:white;
                        font-size:15px;
                        cursor:pointer;
                    ">
                        Cancel
                    </button>

                    <button id="expiredLoginBtn" style="
                        flex:1;
                        min-height:48px;
                        border:0;
                        border-radius:11px;
                        background:#087cff;
                        color:white;
                        font-size:15px;
                        font-weight:700;
                        cursor:pointer;
                    ">
                        Login Now
                    </button>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(modal);

    document.getElementById("expiredCancelBtn").onclick = () => {
        modal.remove();
    };

    document.getElementById("expiredLoginBtn").onclick = () => {
        modal.remove();

        const loginModal =
            document.getElementById("loginModal");

        if (loginModal) {
            loginModal.style.display = "flex";
        } else if (typeof openLogin === "function") {
            openLogin();
        }
    };
}

async function submitWalletDeposit() {
    const token = localStorage.getItem("access_token");

    if (!token) {
        alert("Wallet deposit করতে আগে Login করুন।");
        return;
    }

    const amountInput = document.getElementById("walletAmount");
    const transactionInput = document.getElementById("walletTransactionId");

    const selectedCard = document.querySelector(
        "#walletPaymentAccounts .wallet-payment-card.active"
    );

    const amount = amountInput ? amountInput.value.trim() : "";
    const transactionId = transactionInput
        ? transactionInput.value.trim()
        : "";

    const paymentMethod = selectedCard
        ? selectedCard.dataset.method
        : "";

    if (!amount || Number(amount) <= 0) {
        alert("সঠিক amount দিন।");
        if (amountInput) amountInput.focus();
        return;
    }

    if (!paymentMethod) {
        alert("একটি payment method নির্বাচন করুন।");
        return;
    }

    if (!transactionId) {
        alert("Transaction ID / TXID দিন।");
        if (transactionInput) transactionInput.focus();
        return;
    }

    const submitBtn = document.querySelector(
        "#walletModal button[onclick='submitWalletDeposit()']"
    );

    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerText = "Submitting...";
        submitBtn.style.opacity = "0.7";
    }

    try {
        const url =
            `${API}/wallet/deposit` +
            `?amount=${encodeURIComponent(amount)}` +
            `&payment_method=${encodeURIComponent(paymentMethod)}` +
            `&transaction_id=${encodeURIComponent(transactionId)}`;

        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(
                data.detail || "Deposit request failed"
            );
        }

        alert(
            "Deposit request submitted!\n\n" +
            "Amount: ৳" + data.amount + "\n" +
            "Payment Method: " + paymentMethod + "\n" +
            "Transaction ID: " + data.transaction_id + "\n" +
            "Status: " + data.status
        );

        const walletModal = document.getElementById("walletModal");
        if (walletModal) {
            walletModal.remove();
        }

    } catch (error) {
        console.error("Wallet deposit error:", error);

        alert(
            "Deposit failed: " +
            (error.message || "Unknown error")
        );

        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerText = "Submit Deposit";
            submitBtn.style.opacity = "1";
        }
    }
}

async function openOrders(event) {
    if (event) event.preventDefault();

    const token = localStorage.getItem("access_token");

    if (!token) {
        closeLoginRequired();
        openLogin();
        return;
    }

    try {
        const response = await fetch(`${API}/orders`, {
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.detail || "Orders load করা যায়নি");
        }

        let html = `
            <div style="
                position:fixed;
                inset:0;
                background:rgba(0,0,0,.75);
                z-index:99999;
                padding:20px;
                overflow:auto;
            ">
                <div style="
                    max-width:700px;
                    margin:40px auto;
                    background:#111827;
                    border-radius:16px;
                    padding:20px;
                    color:white;
                ">

                    <div style="
                        display:flex;
                        justify-content:space-between;
                        align-items:center;
                        margin-bottom:20px;
                    ">
                        <h2 style="margin:0;">📋 My Orders</h2>

                        <button
                            onclick="this.closest('div[style*=fixed]').remove()"
                            style="
                                background:#ff5252;
                                color:white;
                                border:0;
                                border-radius:8px;
                                padding:8px 14px;
                                font-size:16px;
                            -webkit-text-size-adjust:100%;
                            text-size-adjust:100%;
                            "
                        >
                            ✕
                        </button>
                    </div>
        `;

        if (!data.length) {
            html += `
                <div style="
                    text-align:center;
                    padding:40px 10px;
                    color:#aaa;
                ">
                    <div style="font-size:40px;">📦</div>
                    <p>আপনার এখনো কোনো order নেই।</p>
                </div>
            `;
        } else {
            data.forEach(order => {
                html += `
                    <div style="
                        background:#1b2338;
                        border:1px solid #303a55;
                        border-radius:12px;
                        padding:16px;
                        margin-bottom:12px;
                    ">

                        <div style="
                            display:flex;
                            justify-content:space-between;
                            gap:10px;
                            margin-bottom:10px;
                        ">
                            <b style="color:#ff9d2e;">
                                ${order.public_order_id || "APX-ORDER"}
                            </b>

                            <b style="
    color:${
        order.status === "completed"
            ? "#35d07f"
            : order.status === "processing"
            ? "#4da6ff"
            : order.status === "delivery_failed"
            ? "#ff5252"
            : order.status === "paid"
            ? "#35d07f"
            : "#ffc107"
    };
">
    ${
        order.status === "completed"
            ? "Completed"
            : order.status === "processing"
            ? "Processing"
            : order.status === "delivery_failed"
            ? "Delivery Failed"
            : order.status === "paid"
            ? "Payment Successful"
            : "Pending"
    }
</b>
                            
                        </div>

                        <div>🎮 Game: <b>${order.game_name}</b></div>

                        <div>👤 Player ID: <b>${order.player_id}</b></div>

                        <div>💎 Amount: <b>${order.package_amount}</b></div>

                        <div>💰 Price: <b>৳${order.price}</b></div>

                        <div>
                            💳 Payment:
                            <b>${order.payment_method || "Pending"}</b>
                        </div>

                        <div>
                            🚚 Delivery:
                            <b>${order.supplier_status || "Pending"}</b>
                        </div>

                    </div>
                `;
            });
        }

        html += `
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML("beforeend", html);

    } catch (error) {
        alert("❌ " + error.message);
    }
}

async function loadPaymentAccounts() {

    try {

        const response =
            await fetch(`${API}/payment-accounts`);

        const accounts =
            await response.json();

        const box =
            document.getElementById("manualPaymentBox");

        if (!box) return;

        if (!Array.isArray(accounts) || accounts.length === 0) {

            box.innerHTML = `
                <div class="payment-empty">
                    No payment method available.
                </div>
            `;

            return;
        }

        const paymentOrder = [
            "bKash",
            "Nagad",
            "Rocket",
            "USDT"
        ];

        accounts.sort((a, b) => {

            const ai =
                paymentOrder.indexOf(a.method);

            const bi =
                paymentOrder.indexOf(b.method);

            return (
                (ai === -1 ? 999 : ai) -
                (bi === -1 ? 999 : bi)
            );
        });

        box.innerHTML = `

            <input
                type="hidden"
                id="paymentMethod"
            >

            <div class="payment-method-title">
                <span>Choose Payment Method</span>
                <small>Select one</small>
            </div>

            <div class="payment-method-grid">

                ${accounts.map((a, index) => {

                    let icon = a.image_url || "";

                    return `

                        <button
                            type="button"
                            class="payment-method-card"
                            data-index="${index}"
                        >

                            <span class="payment-check">
                                ✓
                            </span>

                            <span class="payment-method-icon">
				<img
 			            src="${icon}"
			            alt="${a.method}"
				>
			    </span>

                            <span class="payment-method-name">
                                ${a.method}
                            </span>

                        </button>

                    `;

                }).join("")}

            </div>

            <div
                id="selectedPaymentDetails"
                class="selected-payment-details"
            >
                <div class="payment-placeholder">
                    <div>💳</div>
                    <span>
                        Select a payment method
                    </span>
                </div>
            </div>

            <input
                id="transactionId"
                type="text"
                placeholder="Transaction ID / TXID"
                class="payment-input"
            >

            <input
                id="customerEmail"
                type="email"
                placeholder="Your Gmail Address"
                class="payment-input"
            >

        `;

        const methodCards =
            box.querySelectorAll(
                ".payment-method-card"
            );

        methodCards.forEach((card, index) => {

            card.addEventListener("click", () => {

                selectPaymentAccount(
                    accounts[index].method,
                    accounts[index].account_number,
                    accounts[index].account_type || "",
                    accounts[index].network || "",
                    accounts[index].image_url || "",
                    card
                );

            });

        });

    } catch (error) {

        console.error(
            "Payment accounts error:",
            error
        );

        const box =
            document.getElementById(
                "manualPaymentBox"
            );

        if (box) {

            box.innerHTML = `
                <div class="payment-error">
                    ❌ Payment methods load করা যায়নি।
                </div>
            `;

        }

    }
}


function selectPaymentAccount(
    method,
    accountNumber,
    accountType,
    network,
    imageUrl,
    selectedCard
) {

    const methodInput =
        document.getElementById(
            "paymentMethod"
        );

    const details =
        document.getElementById(
            "selectedPaymentDetails"
        );

    if (!methodInput || !details) {
        return;
    }

    methodInput.value = method;

    document
        .querySelectorAll(
            ".payment-method-card"
        )
        .forEach(card => {

            card.classList.remove(
                "selected"
            );

        });

    selectedCard.classList.add(
        "selected"
    );

    details.innerHTML = `

        <div class="selected-payment-header">

            <div class="selected-payment-icon">

                <img
                   src="${imageUrl}"
                   alt="${method}"
                >

            </div>

            <div>

                <strong>
                    ${method}
                </strong>

                <span>
                    Send Money To
                </span>

            </div>

        </div>

        <div class="payment-account-row">

            <strong>
                ${accountNumber}
            </strong>

            <button
                type="button"
                class="payment-copy-btn"
                onclick="
                    copyPayment(
                        '${accountNumber}',
                        this
                    )
                "
            >
                📋 Copy
            </button>

        </div>

        <div class="payment-meta">

            ${accountType
                ? `<span>${accountType}</span>`
                : ""
            }

            ${network
                ? `<span>${network}</span>`
                : ""
            }

        </div>

    `;

}

function copyPayment(number, button) {
    const textarea = document.createElement("textarea");
    textarea.value = number;
    document.body.appendChild(textarea);

    textarea.select();
    document.execCommand("copy");
    textarea.remove();

    const oldToast = document.querySelector(".copy-success-toast");
    if (oldToast) oldToast.remove();

    const toast = document.createElement("div");

    toast.className = "copy-success-toast";

    toast.innerHTML = `
        <span style="
            font-size:18px;
            color:#22c55e;
            font-weight:bold;
        ">✓</span>

        <span style="
            font-weight:600;
        ">Copied Successfully</span>
    `;

    Object.assign(toast.style, {
        position: "absolute",
        background: "#111827",
        color: "#ffffff",
        padding: "9px 14px",
        borderRadius: "10px",
        fontSize: "14px",
        boxShadow: "0 6px 20px rgba(0,0,0,.35)",
        display: "flex",
        alignItems: "center",
        gap: "7px",
        zIndex: "999999",
        border: "1px solid #22c55e",
        whiteSpace: "nowrap",
        opacity: "0",
        transform: "translateY(5px)",
        transition: "all .2s ease"
    });

    document.body.appendChild(toast);

    const rect = button.getBoundingClientRect();

    toast.style.left =
        (window.scrollX + rect.left) + "px";

    toast.style.top =
        (window.scrollY + rect.top - toast.offsetHeight - 8) + "px";

    requestAnimationFrame(() => {
        toast.style.opacity = "1";
        toast.style.transform = "translateY(0)";
    });

    setTimeout(() => {
        toast.style.opacity = "0";
        toast.style.transform = "translateY(5px)";

        setTimeout(() => {
            toast.remove();
        }, 200);
    }, 1500);
}

function showPaymentSuccess(orderId, playerId, status) {
    const oldModal = document.getElementById("paymentSuccessModal");

    if (oldModal) {
        oldModal.remove();
    }

    const modal = document.createElement("div");

    modal.id = "paymentSuccessModal";

    modal.innerHTML = `
        <div class="success-overlay">
            <div class="success-box">

                <div class="success-icon">
                    ✓
                </div>

                <h2>Payment Submitted!</h2>

                <p class="success-subtitle">
                    Your payment has been successfully submitted.
                </p>

                <div class="success-details">

                    <div class="success-row">
                        <span>Order ID</span>
                        <strong>#${orderId}</strong>
                    </div>

                    <div class="success-row">
                        <span>Player ID</span>
                        <strong>${playerId}</strong>
                    </div>

                    <div class="success-row">
                        <span>Status</span>
                        <strong class="status-processing">
                            ${status}
                        </strong>
                    </div>

                </div>

                <button
                    class="success-close"
                    onclick="closePaymentSuccess()"
                >
                    Done
                </button>

            </div>
        </div>
    `;

    document.body.appendChild(modal);
}


function closePaymentSuccess() {
    const modal = document.getElementById("paymentSuccessModal");

    if (modal) {
        modal.remove();
    }
}

function showPaymentError(message) {

    const oldModal =
        document.getElementById("paymentErrorModal");

    if (oldModal) {
        oldModal.remove();
    }

    const modal =
        document.createElement("div");

    modal.id = "paymentErrorModal";

    modal.innerHTML = `
        <div class="error-overlay">
            <div class="error-box">

                <div class="error-icon">
                    !
                </div>

                <h2>Payment Failed</h2>

                <p class="error-subtitle">
                    ${message}
                </p>

                <div class="error-help">
                    Please check your Transaction ID
                    and try again.
                </div>

                <button
                    class="error-close"
                    onclick="closePaymentError()"
                >
                    Try Again
                </button>

            </div>
        </div>
    `;

    document.body.appendChild(modal);
}


function closePaymentError() {

    const modal =
        document.getElementById("paymentErrorModal");

    if (modal) {
        modal.remove();
    }
}

function showLoginRequired() {

    const oldModal =
        document.getElementById("loginRequiredModal");

    if (oldModal) {
        oldModal.remove();
    }

    const modal = document.createElement("div");

    modal.id = "loginRequiredModal";

    modal.innerHTML = `
        <div class="login-required-overlay">

            <div class="login-required-box">

                <div class="login-required-icon">
                    🔐
                </div>

                <h2>Login Required</h2>

                <p>
                    Wallet ব্যবহার করতে আগে
                    আপনার account-এ Login করুন।
                </p>

                <div class="login-required-actions">

                    <button
                        class="login-required-login"
                        onclick="closeLoginRequired(); openLogin();"
                    >
                        Login
                    </button>

                    <button
                        class="login-required-cancel"
                        onclick="closeLoginRequired()"
                    >
                        Cancel
                    </button>

                </div>

            </div>

        </div>
    `;

    document.body.appendChild(modal);
}


function closeLoginRequired() {

    const modal =
        document.getElementById("loginRequiredModal");

    if (modal) {
        modal.remove();
    }
}

// ================= SUPPORT =================

function openSupport(event) {

    if (event) {
        event.preventDefault();
    }

    // Remove old popup if already exists
    const oldPopup = document.getElementById("supportModal");

    if (oldPopup) {
        oldPopup.remove();
    }

    document.body.insertAdjacentHTML("beforeend", `

        <div
            id="supportModal"
            style="
                position:fixed;
                inset:0;
                background:rgba(0,0,0,0.65);
                display:flex;
                align-items:center;
                justify-content:center;
                z-index:99999;
                padding:15px;
                box-sizing:border-box;
            "
        >

            <div
                style="
                    width:100%;
                    max-width:520px;
                    max-height:90vh;
                    overflow-y:auto;
                    background:#10182d;
                    color:white;
                    border-radius:16px;
                    padding:20px;
                    box-sizing:border-box;
                    box-shadow:0 20px 60px rgba(0,0,0,.4);
                "
            >

                <div
                    style="
                        display:flex;
                        justify-content:space-between;
                        align-items:center;
                        margin-bottom:18px;
                    "
                >

                    <h2 style="margin:0;">
                        🎧 Support
                    </h2>

                    <button
                        onclick="document.getElementById('supportModal').remove()"
                        style="
                            border:none;
                            background:#263452;
                            color:white;
                            width:38px;
                            height:38px;
                            border-radius:50%;
                            font-size:22px;
                            cursor:pointer;
                        "
                    >
                        ×
                    </button>

                </div>


                <p
                    style="
                        color:#b8c2d9;
                        margin-top:0;
                        line-height:1.5;
                    "
                >
                    Payment করেছেন কিন্তু order/product পাননি?
                    নিচের তথ্য দিয়ে Support Request পাঠান।
                </p>


                <label style="display:block;margin:12px 0 6px;">
                    Order ID
                </label>

                <input
                    id="supportOrderId"
                    type="text"
                    placeholder="Enter Order ID"
                    style="
                        width:100%;
                        box-sizing:border-box;
                        padding:13px;
                        border-radius:8px;
                        border:1px solid #39425d;
                        background:#1b2338;
                        color:white;
                    "
                >


                <label style="display:block;margin:12px 0 6px;">
                    Email
                </label>

                <input
                    id="supportEmail"
                    type="email"
                    placeholder="Your email address"
                    style="
                        width:100%;
                        box-sizing:border-box;
                        padding:13px;
                        border-radius:8px;
                        border:1px solid #39425d;
                        background:#1b2338;
                        color:white;
                    "
                >


                <label style="display:block;margin:12px 0 6px;">
                    Payment Method
                </label>

                <select
                    id="supportPaymentMethod"
                    style="
                        width:100%;
                        box-sizing:border-box;
                        padding:13px;
                        border-radius:8px;
                        border:1px solid #39425d;
                        background:#1b2338;
                        color:white;
                    "
                >

                    <option value="">
                        Select payment method
                    </option>

                    <option value="bKash">
                        bKash
                    </option>

                    <option value="Nagad">
                        Nagad
                    </option>

                    <option value="Rocket">
                        Rocket
                    </option>

                    <option value="USDT">
                        USDT
                    </option>

                    <option value="Wallet">
                        Wallet
                    </option>

                </select>


                <label style="display:block;margin:12px 0 6px;">
                    Transaction ID
                </label>

                <input
                    id="supportTransactionId"
                    type="text"
                    placeholder="Enter Transaction ID"
                    style="
                        width:100%;
                        box-sizing:border-box;
                        padding:13px;
                        border-radius:8px;
                        border:1px solid #39425d;
                        background:#1b2338;
                        color:white;
                    "
                >


                <label style="display:block;margin:12px 0 6px;">
                    Problem
                </label>

                <textarea
                    id="supportMessage"
                    rows="5"
                    placeholder="Describe your problem..."
                    style="
                        width:100%;
                        box-sizing:border-box;
                        padding:13px;
                        border-radius:8px;
                        border:1px solid #39425d;
                        background:#1b2338;
                        color:white;
                        resize:vertical;
                    "
                ></textarea>


                <label style="display:block;margin:12px 0 6px;">
                    Payment Screenshot / Document
                </label>

                <input
                    id="supportDocument"
                    type="file"
                    accept="image/*,.pdf"
                    style="
                        width:100%;
                        box-sizing:border-box;
                        padding:10px;
                        border-radius:8px;
                        border:1px solid #39425d;
                        background:#1b2338;
                        color:white;
                    "
                >


                <button
                    id="supportSubmitBtn"
                    onclick="submitSupportRequest()"
                    style="
                        width:100%;
                        margin-top:18px;
                        border:none;
                        background:#1468ff;
                        color:white;
                        padding:14px;
                        border-radius:9px;
                        font-size:16px;
                            -webkit-text-size-adjust:100%;
                            text-size-adjust:100%;
                        font-weight:bold;
                        cursor:pointer;
                    "
                >
                    Submit Support Request
                </button>

                <div style="margin-top:10px;text-align:center;color:#8fa0bc;font-size:13px;">
                    অথবা সরাসরি আমাদের সাথে কথা বলুন
                </div>

                <a
                    href="https://wa.me/+8801818019045"
                    target="_blank"
                    rel="noopener noreferrer"
                    style="
                        display:flex;
                        align-items:center;
                        justify-content:center;
                        gap:8px;
                        width:100%;
                        margin-top:10px;
                        padding:12px 16px;
                        box-sizing:border-box;
                        border-radius:11px;
                        background:#25D366;
                        color:#ffffff;
                        text-decoration:none;
                        font-size:15px;
                        font-weight:700;
                    "
                >
                    <span style="font-size:20px;">💬</span>
                    WhatsApp Support
                </a>

            </div>

        </div>

    `);
}


// ================= SUBMIT SUPPORT REQUEST =================

async function submitSupportRequest() {

    const orderId = document.getElementById("supportOrderId")?.value.trim();
    const email = document.getElementById("supportEmail")?.value.trim();
    const paymentMethod = document.getElementById("supportPaymentMethod")?.value;
    const transactionId = document.getElementById("supportTransactionId")?.value.trim();
    const problem = document.getElementById("supportMessage")?.value.trim();
    const documentFile = document.getElementById("supportDocument")?.files?.[0];
    const button = document.getElementById("supportSubmitBtn");

    if (!orderId) {
        alert("Order ID দিন।");
        return;
    }

    if (!email) {
        alert("আপনার Email দিন।");
        return;
    }

    if (!paymentMethod) {
        alert("Payment Method select করুন।");
        return;
    }

    if (!problem) {
        alert("আপনার Problem লিখুন।");
        return;
    }

    const formData = new FormData();

    formData.append("order_id", orderId);
    formData.append("customer_email", email);
    formData.append("payment_method", paymentMethod);
    formData.append("transaction_id", transactionId || "");
    formData.append("problem", problem);

    if (documentFile) {
        formData.append("document", documentFile);
    }

    button.disabled = true;
    button.textContent = "Sending...";

    try {

        const response = await fetch(`${API}/support`, {
            method: "POST",
            body: formData
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.detail || "Support request failed");
        }

        // Modern ApexGamer success popup
        const oldSuccess = document.getElementById("supportSuccessModal");

        if (oldSuccess) {
            oldSuccess.remove();
        }

        document.body.insertAdjacentHTML("beforeend", `
            <div
                id="supportSuccessModal"
                style="
                    position:fixed;
                    inset:0;
                    z-index:100000;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    padding:20px;
                    box-sizing:border-box;
                    background:rgba(3,8,20,.72);
                    backdrop-filter:blur(6px);
                "
            >
                <div
                    style="
                        width:100%;
                        max-width:390px;
                        background:#0d172d;
                        border:1px solid rgba(59,130,246,.25);
                        border-radius:22px;
                        padding:30px 24px 24px;
                        box-sizing:border-box;
                        text-align:center;
                        box-shadow:0 25px 80px rgba(0,0,0,.55);
                    "
                >

                    <div
                        style="
                            width:72px;
                            height:72px;
                            margin:0 auto 18px;
                            border-radius:50%;
                            display:flex;
                            align-items:center;
                            justify-content:center;
                            background:rgba(34,197,94,.14);
                            border:1px solid rgba(34,197,94,.3);
                            font-size:38px;
                        "
                    >
                        ✓
                    </div>

                    <h2
                        style="
                            margin:0 0 10px;
                            color:#ffffff;
                            font-size:23px;
                            font-weight:800;
                        "
                    >
                        Support Request Sent!
                    </h2>

                    <p
                        style="
                            margin:0 0 24px;
                            color:#aebbd2;
                            font-size:15px;
                            line-height:1.6;
                        "
                    >
                        আপনার report সফলভাবে আমাদের কাছে পৌঁছেছে।
                        আমরা বিষয়টি review করব।
                    </p>

                    <button
                        type="button"
                        onclick="
                            document.getElementById('supportSuccessModal')?.remove();
                            document.getElementById('supportModal')?.remove();
                        "
                        style="
                            width:100%;
                            padding:13px 18px;
                            border:0;
                            border-radius:11px;
                            background:#1468ff;
                            color:#ffffff;
                            font-size:16px;
                            -webkit-text-size-adjust:100%;
                            text-size-adjust:100%;
                            font-weight:700;
                            cursor:pointer;
                        "
                    >
                        Done
                    </button>

                </div>
            </div>
        `);

    } catch (error) {

        console.error("Support request error:", error);

        alert(
            "❌ Support Request পাঠানো যায়নি।\n\n" +
            error.message
        );

        button.disabled = false;
        button.textContent = "Submit Support Request";
    }
}

function openSafeSecure(event) {
    if (event) event.preventDefault();

    const oldModal = document.getElementById("safeSecureModal");
    if (oldModal) oldModal.remove();

    const modal = document.createElement("div");
    modal.id = "safeSecureModal";

    modal.innerHTML = `
        <div style="
            position:fixed;
            inset:0;
            z-index:99999;
            background:rgba(0,0,0,.65);
            backdrop-filter:blur(7px);
            display:flex;
            align-items:center;
            justify-content:center;
            padding:20px;
            box-sizing:border-box;
        "
        onclick="if(event.target===this) this.parentElement.remove()">

            <div style="
                width:100%;
                max-width:430px;
                background:#111c2e;
                color:#fff;
                border-radius:20px;
                padding:24px;
                box-sizing:border-box;
                box-shadow:0 20px 60px rgba(0,0,0,.45);
                border:1px solid rgba(255,255,255,.08);
            ">

                <div style="
                    width:58px;
                    height:58px;
                    border-radius:16px;
                    background:#fff3d6;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    font-size:30px;
                    margin-bottom:16px;
                ">
                    🛡️
                </div>

                <h2 style="
                    margin:0 0 10px;
                    font-size:22px;
                ">
                    Safe & Secure
                </h2>

                <p style="
                    margin:0 0 12px;
                    color:#4da3ff;
                    font-size:16px;
                            -webkit-text-size-adjust:100%;
                            text-size-adjust:100%;
                    font-weight:700;
                    line-height:1.5;
                ">
                    ApexGamer — Fast, reliable & secure gaming top-ups.
                </p>

                <p style="
                    margin:0;
                    color:#b8c5d8;
                    font-size:14px;
                    line-height:1.7;
                ">
                    Your payment and order information are handled securely.
                    We provide a simple and reliable gaming top-up experience
                    with trusted payment options and customer support.
                </p>

                <div style="
                    margin-top:20px;
                    display:grid;
                    gap:10px;
                ">
                    <div style="
                        padding:12px 14px;
                        border-radius:12px;
                        background:#18283e;
                        font-size:14px;
                    ">
                        ✓ Secure Payment
                    </div>

                    <div style="
                        padding:12px 14px;
                        border-radius:12px;
                        background:#18283e;
                        font-size:14px;
                    ">
                        ✓ Fast Delivery
                    </div>

                    <div style="
                        padding:12px 14px;
                        border-radius:12px;
                        background:#18283e;
                        font-size:14px;
                    ">
                        ✓ 24/7 Customer Support
                    </div>
                </div>

                <button
                    onclick="document.getElementById('safeSecureModal').remove()"
                    style="
                        width:100%;
                        margin-top:20px;
                        padding:13px;
                        border:none;
                        border-radius:11px;
                        background:#1468ff;
                        color:#fff;
                        font-size:15px;
                        font-weight:700;
                        cursor:pointer;
                    "
                >
                    Got it
                </button>

            </div>
        </div>
    `;

    document.body.appendChild(modal);
}


function toggleAllGamesMenu(event) {
    event.stopPropagation();

    const menu = document.getElementById("allGamesMenu");
    if (!menu) return;

    menu.style.display =
        menu.style.display === "block" ? "none" : "block";
}

function showAllGames(event) {
    if (event) event.preventDefault();
    if (event) event.stopPropagation();

    showingAllGames = true;

    if (typeof renderGames === "function") {
        renderGames(games);
    }

    const gamesSection = document.getElementById("gamesContainer");

    if (gamesSection) {
        gamesSection.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });
    }
}


/* =========================================================
   APEXGAMER UNIVERSAL BACK / FORWARD NAVIGATION
   ========================================================= */

(function () {
    "use strict";

    if (window.__apexUniversalHistory) {
        return;
    }

    window.__apexUniversalHistory = true;

    let restoring = false;

    /*
     * Initial page = Home
     */
    if (!history.state || !history.state.apexGamer) {
        history.replaceState(
            {
                apexGamer: true,
                page: "home"
            },
            "",
            location.href
        );
    }

    function pushPage(page, data = {}) {
        if (restoring) return;

        history.pushState(
            {
                apexGamer: true,
                page,
                ...data
            },
            "",
            location.href
        );
    }

    function closeOpenModals() {

        const ids = [
            "supportModal",
            "walletModal",
            "paymentSuccessModal",
            "authModal"
        ];

        ids.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.remove();
        });

        /*
         * Checkout modal does not have a fixed known ID,
         * but it contains #closeCheckout.
         */
        const closeCheckout =
            document.getElementById("closeCheckout");

        if (closeCheckout) {
            let parent = closeCheckout;

            for (let i = 0; i < 6 && parent; i++) {
                if (
                    parent.style &&
                    parent.style.position === "fixed"
                ) {
                    parent.remove();
                    break;
                }

                parent = parent.parentElement;
            }
        }
    }

    function showHomeView() {

        closeOpenModals();

        if (typeof renderGames === "function") {
            renderGames(games);
        }

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    }

    function showGamesView() {

        closeOpenModals();

        if (typeof renderGames === "function") {
            renderGames(games);
        }

        const gamesSection =
            document.getElementById("gamesContainer");

        if (gamesSection) {
            gamesSection.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });
        }
    }

    /*
     * Save original functions
     */
    const originalSelectGame =
        window.selectGame;

    const originalBuyPackage =
        window.buyPackage;

    const originalGoHome =
        window.goHome;

    const originalGoGames =
        window.goGames;

    const originalOpenWallet =
        window.openWallet;

    const originalOpenOrders =
        window.openOrders;

    const originalOpenSupport =
        window.openSupport;

    const originalOpenSafeSecure =
        window.openSafeSecure;


    /*
     * HOME
     */
    if (typeof originalGoHome === "function") {

        window.goHome = function (event) {

            if (event) {
                event.preventDefault();
            }

            pushPage("home");

            return originalGoHome.apply(
                this,
                arguments
            );
        };
    }


    /*
     * ALL GAMES
     */
    if (typeof originalGoGames === "function") {

        window.goGames = function (event) {

            if (event) {
                event.preventDefault();
            }

            pushPage("games");

            return originalGoGames.apply(
                this,
                arguments
            );
        };
    }


    /*
     * GAME → PACKAGES
     */
    if (typeof originalSelectGame === "function") {

        window.selectGame = async function (gameId) {

            pushPage(
                "game",
                {
                    gameId: gameId
                }
            );

            return originalSelectGame.apply(
                this,
                arguments
            );
        };
    }


    /*
     * PACKAGE → CHECKOUT
     */
    if (typeof originalBuyPackage === "function") {

        window.buyPackage = async function (
            packageId,
            amount,
            price
        ) {

            pushPage(
                "checkout",
                {
                    packageId: packageId,
                    amount: amount,
                    price: price
                }
            );

            return originalBuyPackage.apply(
                this,
                arguments
            );
        };
    }


    /*
     * WALLET
     */
    if (typeof originalOpenWallet === "function") {

        window.openWallet = async function (event) {

            if (event) {
                event.preventDefault();
            }

            pushPage("wallet");

            return originalOpenWallet.apply(
                this,
                arguments
            );
        };
    }


    /*
     * ORDERS
     */
    if (typeof originalOpenOrders === "function") {

        window.openOrders = async function (event) {

            if (event) {
                event.preventDefault();
            }

            pushPage("orders");

            return originalOpenOrders.apply(
                this,
                arguments
            );
        };
    }


    /*
     * SUPPORT
     */
    if (typeof originalOpenSupport === "function") {

        window.openSupport = function (event) {

            if (event) {
                event.preventDefault();
            }

            pushPage("support");

            return originalOpenSupport.apply(
                this,
                arguments
            );
        };
    }


    /*
     * SAFE & SECURE
     */
    if (typeof originalOpenSafeSecure === "function") {

        window.openSafeSecure = function (event) {

            if (event) {
                event.preventDefault();
            }

            pushPage("safe");

            return originalOpenSafeSecure.apply(
                this,
                arguments
            );
        };
    }


    /*
     * ANDROID / CHROME BACK + FORWARD
     */
    window.addEventListener(
        "popstate",
        function (event) {

            restoring = true;

            const state = event.state;

            try {

                /*
                 * HOME
                 */
                if (
                    !state ||
                    !state.apexGamer ||
                    state.page === "home"
                ) {
                    showHomeView();
                    return;
                }


                /*
                 * ALL GAMES
                 */
                if (state.page === "games") {
                    showGamesView();
                    return;
                }


                /*
                 * GAME / PACKAGES
                 */
                if (
                    state.page === "game" &&
                    state.gameId != null
                ) {

                    closeOpenModals();

                    if (
                        typeof originalSelectGame ===
                        "function"
                    ) {
                        originalSelectGame(
                            state.gameId
                        );
                    }

                    return;
                }


                /*
                 * CHECKOUT
                 */
                if (
                    state.page === "checkout" &&
                    state.packageId != null
                ) {

                    closeOpenModals();

                    if (
                        typeof originalBuyPackage ===
                        "function"
                    ) {
                        originalBuyPackage(
                            state.packageId,
                            state.amount,
                            state.price
                        );
                    }

                    return;
                }


                /*
                 * WALLET
                 */
                if (state.page === "wallet") {

                    closeOpenModals();

                    if (
                        typeof originalOpenWallet ===
                        "function"
                    ) {
                        originalOpenWallet();
                    }

                    return;
                }


                /*
                 * ORDERS
                 */
                if (state.page === "orders") {

                    closeOpenModals();

                    if (
                        typeof originalOpenOrders ===
                        "function"
                    ) {
                        originalOpenOrders();
                    }

                    return;
                }


                /*
                 * SUPPORT
                 */
                if (state.page === "support") {

                    closeOpenModals();

                    if (
                        typeof originalOpenSupport ===
                        "function"
                    ) {
                        originalOpenSupport();
                    }

                    return;
                }


                /*
                 * SAFE & SECURE
                 */
                if (state.page === "safe") {

                    closeOpenModals();

                    if (
                        typeof originalOpenSafeSecure ===
                        "function"
                    ) {
                        originalOpenSafeSecure();
                    }

                    return;
                }

            } finally {

                setTimeout(
                    function () {
                        restoring = false;
                    },
                    0
                );
            }
        }
    );

})();



function togglePassword(inputId, button) {
    const input = document.getElementById(inputId);

    if (input.type === "password") {
        input.type = "text";
        button.textContent = "🙈";
        button.setAttribute("aria-label", "Hide password");
    } else {
        input.type = "password";
        button.textContent = "👁";
        button.setAttribute("aria-label", "Show password");
    }
}


function togglePassword(inputId, button) {
    const input = document.getElementById(inputId);

    if (!input) return;

    if (input.type === "password") {
        input.type = "text";
        button.textContent = "🙈";
    } else {
        input.type = "password";
        button.textContent = "👁️";
    }
}

