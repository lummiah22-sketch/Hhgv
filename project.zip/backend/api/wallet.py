from fastapi import APIRouter

router = APIRouter()

@router.get("/wallet")
async def wallet():
    return {"message": "wallet ok"}
