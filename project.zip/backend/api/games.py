from fastapi import APIRouter, Depends
from sqlalchemy import select

from app.models import Game, GameCurrency, GamePackage
from app.database import get_db

router = APIRouter()


@router.get("/games")
async def games(db = Depends(get_db)):

    result = await db.execute(
        select(Game)
        .where(Game.is_active == True)
    )

    games = result.scalars().all()

    output = []

    for game in games:

        currency_result = await db.execute(
            select(GameCurrency)
            .where(
                GameCurrency.game_id == game.id,
                GameCurrency.is_active == True
            )
        )

        currencies = currency_result.scalars().all()

        products = []

        for currency in currencies:

            package_result = await db.execute(
                select(GamePackage)
                .where(
                    GamePackage.currency_id == currency.id,
                    GamePackage.is_active == True
                )
            )

            packages = package_result.scalars().all()

            for package in packages:
                products.append({
                    "name": currency.name,
                    "amount": package.amount,
                    "price": package.selling_price
                })


        output.append({
            "id": game.id,
            "name": game.name,
            "image": game.image_url,
            "products": products
        })

    return output



@router.get("/games/popular-products")
async def popular_products(db = Depends(get_db)):

    result = await db.execute(
        select(
            GamePackage.id,
            GameCurrency.name.label("currency_name"),
            GamePackage.amount,
            Game.name.label("game_name"),
            GamePackage.selling_price
        )
        .join(
            GameCurrency,
            GamePackage.currency_id == GameCurrency.id
        )
        .join(
            Game,
            GameCurrency.game_id == Game.id
        )
        .where(
            GamePackage.is_active == True
        )
    )


    products = result.all()


    return [
        {
            "id": p.id,
            "currency_name": p.currency_name,
            "amount": p.amount,
            "game_name": p.game_name,
            "selling_price": p.selling_price
        }
        for p in products
    ]

@router.get("/games/{game_id}/currencies")
async def get_currencies(game_id: int, db = Depends(get_db)):

    result = await db.execute(
        select(GameCurrency)
        .where(
            GameCurrency.game_id == game_id,
            GameCurrency.is_active == True
        )
    )

    currencies = result.scalars().all()

    return [
        {
            "id": c.id,
            "name": c.name
        }
        for c in currencies
    ]


@router.get("/games/currencies/{currency_id}/packages")
async def get_packages(
    currency_id: int,
    db = Depends(get_db)
):

    result = await db.execute(
        select(GamePackage)
        .where(
            GamePackage.currency_id == currency_id,
            GamePackage.is_active == True
        )
    )

    packages = result.scalars().all()

    return [
        {
            "id": p.id,
            "amount": p.amount,
            "selling_price": p.selling_price
        }
        for p in packages
    ]
