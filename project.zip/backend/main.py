from app.api.payment_accounts import router as payment_accounts_router
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from pathlib import Path

from app.config import settings
from app.database import create_tables

from api.users import router as users_router
from api.auth import router as auth_router
from api.wallet import router as wallet_router
from api.games import router as games_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    await create_tables()
    yield

app = FastAPI(
    title=settings.app_name,
    version="1.0.0",
    lifespan=lifespan
)


BASE_DIR = Path(__file__).resolve().parent


app.mount(
    "/assets",
    StaticFiles(directory=BASE_DIR / "assets"),
    name="assets"
)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


app.include_router(users_router)
app.include_router(auth_router)
app.include_router(wallet_router)
app.include_router(games_router)
app.include_router(payment_accounts_router)

@app.get("/")
async def root():
    return {
        "message": "Welcome to topup.com",
        "status": "online"
    }


@app.get("/health")
async def health():
    return {
        "status": "ok"
    }
