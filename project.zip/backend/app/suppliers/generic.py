import httpx

from .base import SupplierAdapter


class GenericSupplierAdapter(SupplierAdapter):

    name = "generic"

    def __init__(
        self,
        *,
        api_url: str,
        api_key: str,
        order_path: str = "/api/orders",
    ):
        self.api_url = api_url.rstrip("/")
        self.api_key = api_key
        self.order_path = order_path

    async def create_order(
        self,
        *,
        product_id: str,
        variation_id: str | None,
        player_id: str,
        order_id: int,
        quantity: int = 1,
    ) -> dict:

        payload = {
            "product_id": product_id,
            "variation_id": variation_id,
            "quantity": quantity,
            "client_ref": f"apexgamer-order-{order_id}",
            "player_id": player_id,
        }

        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                response = await client.post(
                    self.api_url + self.order_path,
                    headers=headers,
                    json=payload,
                )

            try:
                data = response.json()
            except Exception:
                data = {}

            if not 200 <= response.status_code < 300:
                return {
                    "success": False,
                    "status": "supplier_http_error",
                    "supplier_order_id": None,
                    "supplier_name": self.name,
                    "message": data.get(
                        "message",
                        response.text[:500],
                    ),
                    "response": data,
                }

            return {
                "success": True,
                "status": data.get("status", "processing"),
                "supplier_order_id": str(
                    data.get("order_id")
                    or data.get("id")
                    or ""
                ) or None,
                "supplier_name": self.name,
                "message": "Supplier order submitted.",
                "response": data,
            }

        except Exception as exc:
            return {
                "success": False,
                "status": "supplier_connection_error",
                "supplier_order_id": None,
                "supplier_name": self.name,
                "message": str(exc),
            }
