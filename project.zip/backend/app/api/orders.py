import secrets
import string

from ..models import User
from ..security import get_current_user_id, get_current_user_id_optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..database import get_db
from ..models import GamePackage, GameCurrency, Game, Order

from ..supplier import deliver_order
from ..email_service import send_order_email

def generate_public_order_id():
    chars = string.ascii_uppercase + string.digits
    code = "".join(secrets.choice(chars) for _ in range(6))
    return f"APX-{code}"

router = APIRouter(
    prefix="/orders",
    tags=["Orders"],
)


@router.post("")
async def create_order(
    package_id: int,
    player_id: str,
    db: AsyncSession = Depends(get_db),
    user_id: int | None = Depends(get_current_user_id_optional),
):

    if not player_id.strip():
        raise HTTPException(
            status_code=400,
            detail="Player ID is required",
        )

    result = await db.execute(
        select(
            GamePackage,
            GameCurrency,
            Game,
        )
        .join(
            GameCurrency,
            GamePackage.currency_id == GameCurrency.id,
        )
        .join(
            Game,
            GameCurrency.game_id == Game.id,
        )
        .where(
            GamePackage.id == package_id,
            GamePackage.is_active == True,
            GameCurrency.is_active == True,
            Game.is_active == True,
        )
    )

    row = result.first()

    if row is None:
        raise HTTPException(
            status_code=404,
            detail="Package not found",
        )

    package, currency, game = row

    order = Order(
        public_order_id=generate_public_order_id(),
        user_id=user_id,
        package_id=package.id,
        player_id=player_id.strip(),
        game_name=game.name,
        package_amount=package.amount,
        price=package.selling_price,
        status="pending",
    )

    db.add(order)

    await db.commit()
    await db.refresh(order)

    return {
        "message": "Order created successfully",
        "order_id": order.id,
        "player_id": order.player_id,
        "game_name": order.game_name,
        "amount": order.package_amount,
        "price": order.price,
        "status": order.status,
    }

@router.get("")
async def get_my_orders(
    user_id: int = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Order)
        .where(Order.user_id == user_id)
        .order_by(Order.id.desc())
    )

    orders = result.scalars().all()

    return [
        {
            "order_id": order.id,
            "public_order_id": order.public_order_id,
            "game_name": order.game_name,
            "player_id": order.player_id,
            "package_amount": order.package_amount,
            "price": order.price,
            "payment_method": order.payment_method,
            "status": order.status,
            "supplier_status": order.supplier_status,
            "created_at": order.created_at,
        }
        for order in orders
    ]


@router.post("/{order_id}/payment")
async def confirm_payment(
    order_id: int,
    payment_method: str,
    transaction_id: str,
    customer_email: str,
    db: AsyncSession = Depends(get_db),
):
    payment_method = payment_method.strip()
    transaction_id = transaction_id.strip()

    if not payment_method:
        raise HTTPException(
            status_code=400,
            detail="Payment method is required",
        )

    if not transaction_id:
        raise HTTPException(
            status_code=400,
            detail="Transaction ID is required",
        )

    # Check order
    result = await db.execute(
        select(Order).where(Order.id == order_id)
    )

    order = result.scalar_one_or_none()

    if not order:
        raise HTTPException(
            status_code=404,
            detail="Order not found",
        )

    if order.status != "pending":
        raise HTTPException(
            status_code=400,
            detail="Order is not pending",
        )

    # Prevent duplicate transaction
    result = await db.execute(
        select(Order).where(
            Order.transaction_id == transaction_id
        )
    )

    existing_order = result.scalar_one_or_none()

    if existing_order:
        raise HTTPException(
            status_code=400,
            detail="Transaction ID already used",
        )

    # Save payment information
    order.payment_method = payment_method
    order.transaction_id = transaction_id
    order.status = "paid"

    await db.commit()
    await db.refresh(order)

    # Keep paid order in Original Orders.
    # Admin can move it to Processing from the existing Admin Panel.
    order.supplier_status = None
    order.supplier_order_id = None

    await db.commit()
    await db.refresh(order)

    try:
        await send_order_email(
            to_email=customer_email.strip(),
            order_id=order.id,
            game_name=order.game_name,
            player_id=order.player_id,
            package_amount=order.package_amount,
            price=order.price,
            payment_method=order.payment_method,
            status=order.status,
        )
    except Exception as e:
        print("ORDER EMAIL FAILED:", e)

    return {
        "message": "Payment confirmed",
        "order_id": order.id,
        "payment_method": order.payment_method,
        "transaction_id": order.transaction_id,
        "payment_status": "paid",
        "supplier_status": order.supplier_status,
        "order_status": order.status,
    }


@router.post("/{order_id}/wallet-payment")
async def wallet_payment(
    order_id: int,
    user_id: int = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Order).where(Order.id == order_id)
    )

    order = result.scalar_one_or_none()

    if not order:
        raise HTTPException(
            status_code=404,
            detail="Order not found",
        )

    if order.status != "pending":
        raise HTTPException(
            status_code=400,
            detail="Order is not pending",
        )

    # Order must belong to the logged-in user
    if order.user_id != user_id:
        raise HTTPException(
            status_code=403,
            detail="This order does not belong to you",
        )

    result = await db.execute(
        select(User).where(User.id == user_id)
    )

    user = result.scalar_one_or_none()

    if not user:
        raise HTTPException(
            status_code=404,
            detail="User not found",
        )

    if user.wallet_balance < order.price:
        raise HTTPException(
            status_code=400,
            detail="Insufficient wallet balance",
        )

    # Deduct wallet
    user.wallet_balance -= order.price

    order.payment_method = "wallet"
    order.transaction_id = f"WALLET-{order.id}-{user_id}"
    order.status = "paid"

    await db.commit()
    await db.refresh(order)

    # Keep wallet-paid order in paid state.
    # Admin must manually approve it from Original Orders.
    # Supplier delivery is triggered only by Admin "Approve & Send".

    order.supplier_status = None
    order.supplier_order_id = None

    await db.commit()
    await db.refresh(order)

    return {
        "message": "Wallet payment successful. Order is awaiting admin approval.",
        "order_id": order.id,
        "public_order_id": order.public_order_id,
        "player_id": order.player_id,
        "game_name": order.game_name,
        "amount": order.package_amount,
        "price": order.price,
        "payment_method": order.payment_method,
        "transaction_id": order.transaction_id,
        "payment_status": "paid",
        "order_status": order.status,
    }
