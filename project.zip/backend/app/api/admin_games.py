from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from ..database import get_db
from ..models import Game, GameCurrency, GamePackage
from .admin import require_admin


router = APIRouter(
    prefix="/admin/games",
    tags=["Admin Games"],
)


@router.post("")
async def add_game(
    name: str,
    slug: str,
    image_url: str = "",
    admin_id: int = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):

    game = Game(
        name=name,
        slug=slug,
        image_url=image_url,
    )

    db.add(game)
    await db.commit()
    await db.refresh(game)

    return {
        "message":"Game added",
        "id":game.id
    }



@router.post("/{game_id}/currency")
async def add_currency(
    game_id:int,
    name:str,
    symbol:str,
    admin_id:int = Depends(require_admin),
    db:AsyncSession = Depends(get_db),
):

    currency = GameCurrency(
        game_id=game_id,
        name=name,
        symbol=symbol,
    )

    db.add(currency)
    await db.commit()

    return {
        "message":"Currency added"
    }



@router.post("/currency/{currency_id}/package")
async def add_package(
    currency_id:int,
    amount:int,
    cost_price:int,
    selling_price:int,
    admin_id:int = Depends(require_admin),
    db:AsyncSession = Depends(get_db),
):

    package = GamePackage(
        currency_id=currency_id,
        amount=amount,
        cost_price=cost_price,
        selling_price=selling_price,
    )

    db.add(package)
    await db.commit()

    return {
        "message":"Package added"
    }
