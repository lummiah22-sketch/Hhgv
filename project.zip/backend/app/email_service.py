from email.message import EmailMessage

import aiosmtplib

from .config import settings


async def send_order_email(
    to_email: str,
    order_id: int,
    game_name: str,
    player_id: str,
    package_amount: int,
    price: int,
    payment_method: str,
    status: str,
):
    message = EmailMessage()

    message["From"] = settings.smtp_from
    message["To"] = to_email
    message["Subject"] = f"ApexGamer Order #{order_id}"

    message.set_content(
        f"""ApexGamer Order Notification

Order ID: #{order_id}
Game: {game_name}
Player ID: {player_id}
Package: {package_amount}
Price: ৳{price}
Payment Method: {payment_method}
Order Status: {status}

Thank you for using ApexGamer.
"""
    )

    await aiosmtplib.send(
        message,
        hostname=settings.smtp_host,
        port=settings.smtp_port,
        start_tls=True,
        username=settings.smtp_username,
        password=settings.smtp_password,
    )
