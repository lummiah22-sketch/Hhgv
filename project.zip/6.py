UPDATE games
SET image_url = CASE slug
    WHEN 'blood-strike' THEN 'https://i.postimg.cc/SRypZqxW/blood-strike-fps-for-all-thumbnail.png'
    WHEN 'honor-of-kings' THEN 'https://i.postimg.cc/fWXKCXGS/honorofkings-1674062354288.jpg'
    WHEN 'wuthering-waves' THEN 'https://i.postimg.cc/Hk2HyrWg/wuthering-waves-new-drip-1.jpg'
    WHEN 'delta-force' THEN 'https://i.postimg.cc/jqz15GSV/f5e5f89495b146bf41996a6c746b3f429dcaeb8e1dfb12a9.jpg'
    WHEN 'super-sus' THEN 'https://i.postimg.cc/MZnWF0xs/239968-7-sq.jpg'
    WHEN '8-ball-pool' THEN 'https://i.postimg.cc/7LP4M0m7/81OMg-LAh-LCL.png'
    WHEN 'farlight-84' THEN 'https://i.postimg.cc/3NmzHxtN/1754043191210ye-xun.webp'
    WHEN 'growtopia' THEN 'https://i.postimg.cc/YS0VC3X2/c8i-S-s-Hw-400x400.png'
    WHEN 'marvel-rivals' THEN 'https://i.postimg.cc/TYcHjSFG/Marvel-Rivals-Rogue.jpg'
    WHEN 'zenless-zone-zero' THEN 'https://i.postimg.cc/vHG0mhTw/H3y-Dq-K0LSy-S0Yq-Og-SZ5j-HA-1720700650-zenless-zone-zero.jpg'
    WHEN 'magic-chess-go-go' THEN 'IMAGE_URL_11'
    WHEN 'arena-of-valor' THEN 'IMAGE_URL_12'
    WHEN 'clash-of-clans' THEN 'https://i.postimg.cc/9Xn6Rv32/81Z-V7GJIEL.png'
END
WHERE slug IN (
    'blood-strike',
    'honor-of-kings',
    'wuthering-waves',
    'delta-force',
    'super-sus',
    '8-ball-pool',
    'farlight-84',
    'growtopia',
    'marvel-rivals',
    'zenless-zone-zero',
    'magic-chess-go-go',
    'arena-of-valor',
    'clash-of-clans'
);

