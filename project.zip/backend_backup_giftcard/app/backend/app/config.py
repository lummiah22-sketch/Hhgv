jwt_secret_key: str
jwt_algorithm: str = "HS256"
